var aperto = true;

function menu(){
    if(aperto){
        document.getElementById("menu").style.marginLeft="0px";
        aperto = false
    }else{
        document.getElementById("menu").style.marginLeft="-20vw";
        aperto = true
    }
}

var elenco = true

function Elenco(){
    if(elenco){
        document.getElementById("lista").style.height="3vw";
        document.getElementById("lista").style.marginLeft="0vw";
        elenco = false;
    }else{
        document.getElementById("lista").style.height="1vw";
        document.getElementById("lista").style.marginLeft="-20vw";
        elenco = true
    }
}

var elenco1 = true

function Elenco1(){
    if(elenco1){
        document.getElementById("lista1").style.height="3vw";
        document.getElementById("lista1").style.marginLeft="0vw";
        elenco1 = false
    }else{
        document.getElementById("lista1").style.height="1vw";
        document.getElementById("lista1").style.marginLeft="-20vw";
        elenco1 = true
    }
}