
var cont = 1;

setInterval(Slide, 4000);

function Slide(){
    document.getElementById('radio' + cont).checked = true;
    cont++;
    if(cont > 4){
        cont = 1;
    }
}
